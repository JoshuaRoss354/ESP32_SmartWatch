#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void displayText();
String getDate();

#endif