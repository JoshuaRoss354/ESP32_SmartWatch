#include <Arduino.h>
#include <TFT_eSPI.h>
#include <utilities.h> // Include the header file for initializeRTC() and getTime()
#include "global.h"
#include <WiFi.h>

// Create an instance of the TFT_eSPI class
TFT_eSPI tft = TFT_eSPI(); // ❌ Don't do this here, it's already global


// Function declarations
int myFunction(int, int);
void initializeDisplay();

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("hi");

    const char* ssid     = "edamame";
    const char* password = "mmHellof409";

    Serial.println("Starting WiFi scan...");

    int n = WiFi.scanNetworks();
    Serial.println("Scan done");

    if (n == 0) {
        Serial.println("No networks found.");
    } else {
        Serial.printf("%d networks found:\n", n);
        for (int i = 0; i < n; ++i) {
            Serial.printf("%d: %s (%d) %s\n", i + 1,
                          WiFi.SSID(i).c_str(),
                          WiFi.RSSI(i),
                          (WiFi.encryptionType(i) == WIFI_AUTH_OPEN) ? "open" : "");
            delay(10);
        }
    }

    // Attempt to connect
    Serial.printf("\nConnecting to %s...\n", ssid);
    WiFi.begin(ssid, password);

    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
        delay(500);
        Serial.print(".");
        attempts++;
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\nWiFi connected!");
        Serial.print("IP Address: ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println("\nFailed to connect to WiFi.");
    }

    // Initialize the display
    initializeDisplay();

    Serial.println("Calling displayText...");
    Serial.println("displayText completed.");

    // Print the current time
    String currentTime = getTime();
    Serial.println("Current time: " + currentTime);

    // Display the current time on the screen
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("Current Time:", 10, 10, 2);
    tft.drawString(currentTime, 10, 30, 4);

    int result = myFunction(2, 3);
    Serial.print("myFunction result: ");
    Serial.println(result);
}

void loop() {
    // Update the time on the display every second
    String currentTime = getTime();
    tft.fillRect(10, 30, 200, 40, TFT_BLACK);
    tft.drawString(currentTime, 10, 30, 4);

    Serial.println("Current time: " + currentTime);
    delay(1000);
}

// Initialize the display
void initializeDisplay() {
    tft.init();
    tft.setRotation(1);
    tft.fillScreen(TFT_BLACK);
    tft.setTextSize(1);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("Initializing...", 10, 10, 2);
}

// Simple math function
int myFunction(int x, int y) {
    return x + y;
}
